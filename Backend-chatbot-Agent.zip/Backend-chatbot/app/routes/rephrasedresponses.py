from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from config import get_db
from schemas.rephrasedresponses import (
    RephrasedResponseCreateSchema,
    RephrasedResponseReadSchema,
    RephrasedResponseUpdateSchema,
    ResponseRephrasedResponseSchema,
    ListResponseRephrasedResponseSchema,
)
from database.rephrasedresponses import (
    get_rephrasedresponses,
    get_rephrasedresponse_by_id,
    create_rephrasedresponse,
    delete_rephrasedresponse,
    update_rephrasedresponse,
)

rephrased_response_router = APIRouter(
    prefix="/rephrased_responses",
    tags=["RephrasedResponses"],
    responses={404: {"description": "Not found"}},
)

@rephrased_response_router.get("/", response_model=ListResponseRephrasedResponseSchema)
def read_rephrased_responses(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    rephrased_responses = get_rephrasedresponses(db, skip=skip, limit=limit)
    return {
        "code": "success",
        "status": status.HTTP_200_OK,
        "response": rephrased_responses,
    }

@rephrased_response_router.get("/{response_id}", response_model=ResponseRephrasedResponseSchema)
def read_rephrased_response(response_id: int, db: Session = Depends(get_db)):
    rephrased_response = get_rephrasedresponse_by_id(db, response_id=response_id)
    if rephrased_response is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="RephrasedResponse not found"
        )
    return {
        "code": "success",
        "status": status.HTTP_200_OK,
        "response": rephrased_response,
    }

@rephrased_response_router.post("/", response_model=ResponseRephrasedResponseSchema)
def create_rephrased_response(rephrased_response: RephrasedResponseCreateSchema, db: Session = Depends(get_db)):
    db_rephrased_response = create_rephrasedresponse(db, rephrased_response)
    return {
        "code": "success",
        "status": status.HTTP_201_CREATED,
        "response": db_rephrased_response,
    }

@rephrased_response_router.put("/{response_id}", response_model=ResponseRephrasedResponseSchema)
def update_rephrased_response(response_id: int, rephrased_response: RephrasedResponseUpdateSchema, db: Session = Depends(get_db)):
    db_rephrased_response = get_rephrasedresponse_by_id(db, response_id=response_id)
    if db_rephrased_response is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="RephrasedResponse not found"
        )
    updated_response = update_rephrasedresponse(db, response_id, rephrased_response)
    return {
        "code": "success",
        "status": status.HTTP_200_OK,
        "response": updated_response,
    }

@rephrased_response_router.delete("/{response_id}", response_model=ResponseRephrasedResponseSchema)
def delete_rephrased_response(response_id: int, db: Session = Depends(get_db)):
    db_rephrased_response = get_rephrasedresponse_by_id(db, response_id=response_id)
    if db_rephrased_response is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="RephrasedResponse not found"
        )
    delete_rephrasedresponse(db, response_id)
    return {
        "code": "success",
        "status": status.HTTP_200_OK,
        "response": f"RephrasedResponse with id {response_id} deleted successfully.",
    }
