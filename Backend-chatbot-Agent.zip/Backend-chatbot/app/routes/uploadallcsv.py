from fastapi import APIRouter, Depends, File, UploadFile
from fastapi.responses import JSONResponse
from typing import List
import pandas as pd
import logging
import os
from datetime import datetime

from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_community.tools.sql_database.tool import QuerySQLDataBaseTool
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.chains import create_sql_query_chain
from langchain_chroma import Chroma
from config import DATABASE_URL


from sqlalchemy.orm import Session
from config import get_db
from models.users import User
from models.costs import Cost
from models.ftasks import FTask
from models.portfolios import Portfolio
from models.programs import Program
from models.projects import Project
from models.risks import Risk

from database.users import create_user
from database.costs import create_cost
from database.ftasks import create_ftask
from database.portfolios import create_portfolio
from database.programs import create_program
from database.projects import create_project
from database.risks import create_risk
from database.generatedsqls import create_generatedsql
from database.userqueries import create_userquery
from database.msgs import create_msg
from database.rephrasedresponses import create_rephrasedresponse
from database.chats import create_chat


from schemas.userqueries import UserQueryCreateSchema
from schemas.generatedsqls import GeneratedSqlCreateSchema
from schemas.msgs import MsgCreateSchema
from schemas.ftasks import FTaskCreateSchema
from schemas.projects import ProjectCreateSchema
from schemas.risks import RiskCreateSchema
from schemas.chatbot import QueryRequest
from schemas.rephrasedresponses import RephrasedResponseCreateSchema
from schemas.chats import ChatCreateSchema


from set_chat import get_all_response, get_cost_response,get_project_response,get_risk_response
from set_chat import examples as training_examples






upload_router = APIRouter(
    prefix="/uploadall",
)



class_mappings = {
    "costs": [
        "cost_per_hour",
        "total_hours",
        "fixed_cost",
        "actual_hours",
        "actual_fixed_cost",
        "cost_ftask_id",
        "cost_user_id",
        "cost_story_id",
        "location",
        "created_at",
        "updated_at",
    ],
    "ftasks": [
        "name",
        "description",
        "wbs",
        "current_status",
        "Resource",
        "ActualResource",
        "PlannedStartDate",
        "PlannedEndDate",
        "ActualStartDate",
        "ActualEndDate",
        "action",
        "predecessor_successor",
        "progress",
        "assigned_to",
        "proj_id"
    ],
    "portfolios": [
        "name",
        "description",
        "StartDate",
        "EndDate",
    ],
    "programs": [
        "name",
        "description",
        "portfolio_id",
        "created_at",
        "updated_at",
        "status",
        "StartDate",
        "EndDate",
    ],
    "projects": [
        "name",
        "description",
        "retro",
        "completed",
        "StartDate",
        "EndDate",
        "program_id",
        "project_lifecycle_id"
    ],
    "risks": [
        "type",
        "name",
        "description",
        "mitigation",
        "assigned_to",
        "is_completed",
        "risk_impact",
        "risk_probablitly",
        "DueDate",
        "risk_proj_id",
        "risk_prog_id",
        "risk_port_id"
    ],
    "users": [
        "email",
        "password",
        "username",
        "first_name",
        "last_name",
        "is_system_admin",
        "is_fte",
        "is_business_steward",
        "is_resource",
        "is_onshore",
        "access_level",
        "created_at",
        "updated_at",
    ],
}

db_functions = {
    "costs": create_cost,
    "ftasks": create_ftask,
    "portfolios": create_portfolio,
    "programs": create_program,
    "projects": create_project,
    "risks": create_risk,
    "users": create_user,
}

model_classes = {
    "costs": Cost,
    "ftasks": FTask,
    "portfolios": Portfolio,
    "programs": Program,
    "projects": Project,
    "risks": Risk,
    "users": User
}

def identify_class(df, class_mappings):
    # Convert DataFrame columns to a sorted list
    df_columns = sorted(col.lower() for col in df.columns)
    
    for class_name, required_columns in class_mappings.items():
        # Convert required columns to a sorted list
        required_columns_sorted = sorted(col.lower() for col in required_columns)
        
        # Check if the sorted list of DataFrame columns matches exactly with the sorted list of required columns
        if df_columns == required_columns_sorted:
            return class_name
    
    return None

def process_uploaded_file(
    db: Session,
    file_path: str,
    class_mappings: dict,
    db_functions: dict,
    model_classes: dict,
):
    print(f"Processing file: {file_path}")
    try:
        df = pd.read_csv(file_path)
        print(f"Loaded dataframe with columns: {df.columns.tolist()}")
    except Exception as e:
        print(f"Error loading CSV file {file_path}: {e}")
        return f"Error loading CSV file {file_path}: {e}"

    identified_class = identify_class(df, class_mappings)
    print(f"Identified class: {identified_class}")

    project_id = None  # Initialize project_id to be used for ftasks

    if not identified_class:
        print(
            f"Unable to identify the class of the uploaded file based on its columns: {df.columns.tolist()}"
        )
        return (
            f"Unable to identify the class of the uploaded file based on its columns."
        )
    if identified_class == 'projects':
        result = process_project_file(db, df)
        if "Error" not in result:
            project_id = extract_project_id(db)
        else:
            project_id = None
        return result, project_id



    if identified_class == 'ftasks':
            project_id=extract_project_id(db)
            return process_ftask_file(db, df, project_id)
                
    if identified_class == 'risks':
        return process_risk_file(db, df)

    # Default processing for other classes
    db_function = db_functions[identified_class]
    model_class = model_classes[identified_class]

    try:
        for _, row in df.iterrows():
            row_dict = row.to_dict()
            if 'id' in row_dict:
                del row_dict['id']

            # Handle empty strings for nullable fields
            for key, value in row_dict.items():
                if value == "":
                    row_dict[key] = None

            # Create the model instance
            data = model_class(**row_dict)
            db_function(db, data)
    except Exception as e:
        print(f"Error saving data for class {identified_class}: {e}")
        return f"Error saving data for class {identified_class}: {e}"

    return f"Data successfully processed and saved for class: {identified_class}"

def process_risk_file(db: Session, df: pd.DataFrame):
    # Fill NaN values with None
    df = df.where(pd.notnull(df), None)
    
    # Convert DueDate to datetime object
    df['DueDate'] = pd.to_datetime(df['DueDate'], format='%m/%d/%Y').dt.date

    risks = []
    for _, row in df.iterrows():
        risk_data = row.to_dict()

        # Replace NaN values in integer fields with None
        risk_data['risk_proj_id'] = risk_data.get('risk_proj_id')
        risk_data['risk_prog_id'] = risk_data.get('risk_prog_id')
        risk_data['risk_port_id'] = risk_data.get('risk_port_id')

        # Construct the Risk schema
        risk_schema = RiskCreateSchema(
            type=risk_data.get('type'),
            name=risk_data.get('name'),
            description=risk_data.get('description'),
            mitigation=risk_data.get('mitigation'),
            assigned_to=risk_data.get('assigned_to'),
            is_completed=risk_data.get('is_completed'),
            risk_impact=risk_data.get('risk_impact'),
            risk_probablitly=risk_data.get('risk_probablitly'),
            DueDate=risk_data.get('DueDate'),
            risk_proj_id=risk_data.get('risk_proj_id'),
            risk_prog_id=risk_data.get('risk_prog_id'),
            risk_port_id=risk_data.get('risk_port_id')
        )

        try:
            create_risk(db, risk_schema)
        except Exception as e:
            print(f"Error saving risk: {risk_schema.name}, Error: {e}")
            return f"Error saving risk: {risk_schema.name}, Error: {e}"

    return f"Data successfully processed and saved for risks."

 # Function to process the projects CSV file

def process_project_file(db: Session, df: pd.DataFrame):
    # Fill NaN values with None
    df = df.where(pd.notnull(df), None)
    
    # Convert StartDate and EndDate to datetime objects
    df['StartDate'] = pd.to_datetime(df['StartDate'], format='%Y-%m-%d').dt.date
    df['EndDate'] = pd.to_datetime(df['EndDate'], format='%Y-%m-%d').dt.date

    projects = []
    for _, row in df.iterrows():
        project_data = row.to_dict()

        # Handle the 'completed' field
        if 'completed' in project_data:
            project_data['is_completed'] = project_data.pop('completed')

        # Construct the Project schema
        project_schema = ProjectCreateSchema(
            name=project_data.get('name'),
            description=project_data.get('description'),
            retro=project_data.get('retro'),
            is_completed=project_data.get('is_completed', False),  # Ensure 'is_completed' is handled
            StartDate=project_data.get('StartDate'),
            EndDate=project_data.get('EndDate'),
            program_id=project_data.get('program_id'),
            project_lifecycle_id=project_data.get('project_lifecycle_id')
        )

        try:
            create_project(db, project_schema)
            

        except Exception as e:
            print(f"Error saving project: {project_schema.name}, Error: {e}")
            return f"Error saving project: {project_schema.name}, Error: {e}"

    return f"Data successfully processed and saved for projects."

def process_ftask_file(db: Session, df: pd.DataFrame, project_id: int):
    # Fill NaN values with None
    df = df.where(pd.notnull(df), None)

    for _, row in df.iterrows():
        ftask_data = row.to_dict()

        # Convert specific fields to strings if they are not None
        for key in ['description', 'wbs', 'ActualResource', 'action', 'predecessor_successor']:
            if ftask_data.get(key) is not None:
                ftask_data[key] = str(ftask_data[key])

        # Set the project_id
        ftask_data['proj_id'] = project_id

        # Construct the FTask schema
        ftask_schema = FTaskCreateSchema(
            name=ftask_data.get('name'),
            description=ftask_data.get('description', ''),  # Provide empty string if None
            wbs=ftask_data.get('wbs', ''),
            current_status=ftask_data.get('current_status'),
            Resource=ftask_data.get('Resource', ''),
            ActualResource=ftask_data.get('ActualResource', ''),
            PlannedStartDate=ftask_data.get('PlannedStartDate'),
            PlannedEndDate=ftask_data.get('PlannedEndDate'),
            ActualStartDate=ftask_data.get('ActualStartDate'),
            ActualEndDate=ftask_data.get('ActualEndDate'),
            action=ftask_data.get('action', ''),
            predecessor_successor=ftask_data.get('predecessor_successor', ''),
            progress=ftask_data.get('progress'),
            assigned_to=ftask_data.get('assigned_to'),
            proj_id=project_id
        )

        try:
            create_ftask(db, ftask_schema)
        except Exception as e:
            print(f"Error saving ftask: {ftask_schema.name}, Error: {e}")
            return f"Error saving ftasks: {e}"

    return "Data successfully processed and saved for ftasks."

def extract_project_id(db: Session) -> int:
    # Retrieve the most recent project ID from the database
    project = db.query(Project).order_by(Project.id.desc()).first()
    return project.id if project else None

#Initialize SQLDatabase from databse  URL
chatbot_db = SQLDatabase.from_uri(DATABASE_URL, sample_rows_in_table_info=0)
table_info = chatbot_db.table_info

# Initialize LLMs
llm = ChatOpenAI(model="gpt-4", temperature=0)
llm2 = ChatOpenAI(model='gpt-4', temperature=0.5)

# Create SQL Chain
generate_query = create_sql_query_chain(llm, chatbot_db)
execute_query = QuerySQLDataBaseTool(db=chatbot_db)

# Initialize vectorstore and example selectors
vectorstore = Chroma()
vectorstore.delete_collection()

example_selectors = SemanticSimilarityExampleSelector.from_examples(
    training_examples, OpenAIEmbeddings(), vectorstore, k=3, input_keys=["input"]
)

# Now, chabot_db and other objects are available globally within this module


example_prompt = ChatPromptTemplate.from_messages(
[
    ("human", "{input}\nSQLQuery:"),
    ("ai", "{query}"),
]
)
few_shot_prompt = FewShotChatMessagePromptTemplate(
example_prompt=example_prompt,
example_selector=example_selectors,
input_variables=["input", "top_k"],
) 

@upload_router.post("/upload_all_files")
async def upload_all_files(files: List[UploadFile] = File(...), db: Session = Depends(get_db)):
    results = []
    project_id = None
    
    try:
        for file in files:
            file_path = f"temp_{file.filename}"
            with open(file_path, "wb") as f:
                f.write(await file.read())
            
            # Process each file and save data
            result = process_uploaded_file(db, file_path, class_mappings, db_functions, model_classes)
            results.append(result)
            
            # Dynamically check if the processed file corresponds to the 'projects' class
            if identify_class(pd.read_csv(file_path), class_mappings) == 'projects':
                project_id = extract_project_id(db)
            
            os.remove(file_path)
        
        # Ensure that the project_id was found
        if not project_id: 
            return JSONResponse(
                status_code=400,
                content={"message": "Project ID could not be found. Ensure a project file was uploaded."}
            )
            
    except Exception as e:
        return JSONResponse(
            status_code=500, content={"message": f"Unexpected error: {str(e)}"}
        )

    # Return the project ID in the response
    return {"results": results, "project_id": project_id}

       
