from fastapi import APIRouter, Depends, HTTPException, status, Path,File, UploadFile
from sqlalchemy.orm import Session
from sqlalchemy import join
from datetime import datetime
from schemas import chatbot as schema
import os
import json


import httpx, base64
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File



from config import engine, connect_to_db, close_db_connection, SessionLocal, POSTGRES_CONNECTION, get_db
from fastapi.responses import JSONResponse
from jira.auth import *
import json
import os
from datetime import datetime
from typing import Dict, List

from auth.auth_handler import sign_jwt
from schemas.users import UserCreateSchema, UserLoginSchema
import mpxj
import csv

from fastapi.responses import JSONResponse

from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_community.tools.sql_database.tool import QuerySQLDataBaseTool
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.chains import create_sql_query_chain
from langchain_chroma import Chroma

from config import DATABASE_URL, get_db
from set_chat import get_all_response, get_cost_response, get_project_response, get_risk_response
from database.chats import create_chat
from database.msgs import create_msg
from database.generatedsqls import create_generatedsql
from database.userqueries import create_userquery
from database.rephrasedresponses import create_rephrasedresponse



from schemas.msgs import MsgCreateSchema
from schemas.chats import ChatCreateSchema
from schemas.generatedsqls import GeneratedSqlCreateSchema
from schemas.rephrasedresponses import RephrasedResponseCreateSchema
from schemas.userqueries import UserQueryCreateSchema


from set_chat import examples

chatbot_router = APIRouter(
    prefix="/chatbot",
)

baseURL = 'http://localhost:8000'
headers = {"Content-Type": "application/json", "Accept": "*/*"}
    

chatbot_db = SQLDatabase.from_uri(DATABASE_URL, sample_rows_in_table_info=0)
table_info = chatbot_db.table_info

llm = ChatOpenAI(model="gpt-4", temperature=0)
llm2 = ChatOpenAI(model="gpt-4o", temperature=0.5)

generate_query = create_sql_query_chain(llm, chatbot_db)
execute_query = QuerySQLDataBaseTool(db=chatbot_db)

vectorstore = Chroma()
vectorstore.delete_collection()

example_selectors = SemanticSimilarityExampleSelector.from_examples(
    examples, OpenAIEmbeddings(), vectorstore, k=3, input_keys=["input"]
)

example_prompt = ChatPromptTemplate.from_messages(
    [
        ("human", "{input}\nSQLQuery:"),
        ("ai", "{query}"),
    ]
)
few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_prompt=example_prompt,
    example_selector=example_selectors,
    input_variables=["input", "top_k"],
)


@chatbot_router.post("/AllInOne-bot")
def all_in_one_bot(query: schema.QueryRequest, db: Session = Depends(get_db)):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=4,  # All-in-One bot
            name="All-in-One Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query.question,
            msg_type=0  # 0 indicates this is a human message
        )
        human_msg = create_msg(db, human_msg_schema)
        human_msg_id = human_msg.msg_id

        # Save the user query
        user_query_schema = UserQueryCreateSchema(
            query_text=query.question  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query.question})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get the response
        response = get_all_response(
            query.question, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return {"response": response}

    except Exception as e:
        db.rollback()  # Rollback in case of error
        return {"error": f"Error processing bot interaction: {str(e)}"}


@chatbot_router.post("/cost-bot")
def cost_bot(query: schema.QueryRequest, db: Session = Depends(get_db)):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=1,  # Cost bot
            name="Cost Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query.question,
            msg_type=0  # 0 indicates this is a human message
        )
        human_msg = create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query.question  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query.question})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_cost_response(
            query.question, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return {"response": response}

    except Exception as e:
        db.rollback()
        return {"error": f"Error processing bot interaction: {str(e)}"}


@chatbot_router.post("/project-bot")
def project_bot(query: schema.QueryRequest, db: Session = Depends(get_db)):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=2,  # Project bot
            name="Project Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query.question,
            msg_type=0  # 0 indicates this is a human message
        )
        human_msg = create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query.question  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query.question})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_project_response(
            query.question, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return {"response": response}

    except Exception as e:
        db.rollback()
        return {"error": f"Error processing bot interaction: {str(e)}"}


@chatbot_router.post("/risk-bot")
def risk_bot(query: schema.QueryRequest, db: Session = Depends(get_db)):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=3,  # Risk bot
            name="Risk Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query.question,
            msg_type=0  # 0 indicates this is a human message
        )
        human_msg = create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query.question  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query.question})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_risk_response(
            query.question, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return {"response": response}

    except Exception as e:
        db.rollback()
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=3,  # Risk bot
            name="Risk Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query_text,
            msg_type=0  # 0 indicates this is a human message
        )
        create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query_text  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query_text})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_risk_response(
            query_text, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return response

    except Exception as e:
        db.rollback()
        return {"error": f"Error processing cost query: {str(e)}"}
        return {"error": f"Error processing bot interaction: {str(e)}"}


async def get_csvfile_Content(file: str):
    url = f'{baseURL}/api/ftasks/'  # Fixed typo "taks" to "tasks"
    proj_id = None  # Initialize proj_id
    
    with open(file, 'r') as csv_file:
        reader = csv.DictReader(csv_file)
        list_from_csv = list(reader)

        async with httpx.AsyncClient() as client:
            for row in list_from_csv:
                dict_from_csv = dict(row)
                print(dict_from_csv)

                # Set proj_id from the CSV for the current row
                proj_id = dict_from_csv['proj_id']

                date_format = "%m/%d/%Y"
                ele = {
                    'wbs': dict_from_csv['wbs'],
                    'name': dict_from_csv['name'],
                    'description': dict_from_csv['description'],
                    'current_status': dict_from_csv['current_status'],
                    'Resource': dict_from_csv['Resource'],
                    'ActualResource': dict_from_csv['ActualResource'],
                    'PlannedStartDate': str(datetime.strptime(dict_from_csv['PlannedStartDate'], date_format).date()),
                    'PlannedEndDate': str(datetime.strptime(dict_from_csv['PlannedEndDate'], date_format).date()),
                    'ActualStartDate': str(datetime.strptime(dict_from_csv['ActualStartDate'], date_format).date()),
                    'ActualEndDate': str(datetime.strptime(dict_from_csv['ActualEndDate'], date_format).date()),
                    'action': dict_from_csv['action'],
                    'predecessor_successor': dict_from_csv['predecessor_successor'],
                    'progress': dict_from_csv['progress'],
                    'proj_id': proj_id
                }
                await client.post(url, json=ele, headers=headers)
    
    # Return the proj_id along with the success message
    return JSONResponse(status_code=200, content={"message": "Successfully dumped the data from CSV file!", "proj_id": proj_id})

async def process_cost_query(query_text: str, db: Session):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=1,  # Cost bot
            name="Cost Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query_text,
            msg_type=0  # 0 indicates this is a human message
        )
        create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query_text  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query_text})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_cost_response(
            query_text, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return response

    except Exception as e:
        db.rollback()
        return {"error": f"Error processing cost query: {str(e)}"}

async def process_risk_query(query_text: str, db: Session):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=3,  # Risk bot
            name="Risk Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query_text,
            msg_type=0  # 0 indicates this is a human message
        )
        create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query_text  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query_text})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_risk_response(
            query_text, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return response

    except Exception as e:
        db.rollback()

async def process_project_query(query_text: str, db: Session):
    try:
        # Create chat session
        chat_schema = ChatCreateSchema(
            bot_id=2,  # Project bot
            name="Risk Bot Interaction",
            user_id=None  # User ID can be null if not provided
        )
        chat = create_chat(db, chat_schema)
        chat_id = chat.chat_id

        # Save human message
        human_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=query_text,
            msg_type=0  # 0 indicates this is a human message
        )
        create_msg(db, human_msg_schema)

        # Save the user query and commit to DB
        user_query_schema = UserQueryCreateSchema(
            query_text=query_text  # Use the question as the query text
        )
        user_query = create_userquery(db, user_query_schema)
        db.commit()  # Commit to ensure the user query is saved
        user_query_id = user_query.query_id

        # Generate SQL query
        sql_query = generate_query.invoke({"question": query_text})
        
        # Save generated SQL and link to the user query
        generated_sql_schema = GeneratedSqlCreateSchema(
            query_id=user_query_id,
            sql_text=sql_query
        )
        create_generatedsql(db, generated_sql_schema)

        # Execute the query and get response
        response = get_project_response(
            query_text, few_shot_prompt, llm, llm2, chatbot_db, execute_query
        )

        # Save bot response
        bot_msg_schema = MsgCreateSchema(
            chat_id=chat_id,
            content=response,
            msg_type=1  # 1 indicates this is a bot message
        )
        create_msg(db, bot_msg_schema)

        # Save rephrased response
        rephrased_response_schema = RephrasedResponseCreateSchema(
            query_id=user_query_id,
            response_text=response
        )
        create_rephrasedresponse(db, rephrased_response_schema)

        return response

    except Exception as e:
        db.rollback()
        return {"error": f"Error processing cost query: {str(e)}"}




@chatbot_router.post("/mppupload", summary="Upload csv file for microsoft project")
async def create_upload_csvfile(file: UploadFile = File(...), db: Session = Depends(get_db)):
    try:
        # Save the uploaded file
        date_today = datetime.now().strftime('%Y-%m-%d')
        directory = f'./uploads/{date_today}'

        if not os.path.exists(directory):
            os.makedirs(directory)

        date_time_now = datetime.now().strftime('%H%M%S%f')
        filename = f"{date_time_now}_{file.filename}"
        file_location = f"{directory}/{filename}"
        with open(file_location, "wb+") as file_object:
            file_object.write(await file.read())
        
        # Process the CSV and get the proj_id
        response = await get_csvfile_Content(file_location)
        proj_id = json.loads(response.body)['proj_id']
        
        # Generate the query for the risk bot using the proj_id
        query_text_cost = f"Get me the cost analysis for the project id {proj_id}"
        query_text_project = f"Get me the project analysis for the project id {proj_id}"
        query_text_risk = f"Get me the risk analysis for the project id {proj_id}"
        

        # Pass the query to the cost bot and get the response
        cost_response = await process_cost_query(query_text_cost, db)
        risk_response = await process_risk_query(query_text_risk, db)
        project_response = await process_project_query(query_text_project, db)

        # Return the final response, including proj_id and cost analysis
        return JSONResponse(status_code=200, content={
            "message": "CSV file processed successfully!",
            "proj_id": proj_id,
            "project_analysis": project_response,
            "risk_analysis": risk_response,
            "cost_analysis": cost_response,
            
        })

    except Exception as e:
        # Handle any errors that occur during the file upload or processing
        db.rollback()
        return JSONResponse(status_code=500, content={
            "error": f"An error occurred: {str(e)}"
        })


async def get_recent_story_id():
    try:
        connection = await connect_to_db()
        # Query to get the most recent story ID
        query = """
            SELECT id 
            FROM stories 
            ORDER BY created_at DESC 
            LIMIT 1
        """
        result = await connection.fetch(query)
        await close_db_connection(connection)
        
        if result:
            return result[0]['id']
        else:
            return None
    
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": f"Failed to retrieve recent story ID: {str(e)}"})



async def get_xls_file_content(file: str):
    story_ids = []  # List to store all created story IDs

    with open(file, 'r') as csv_file:
        reader = csv.DictReader(csv_file)
        list_from_csv = list(reader)
        async with httpx.AsyncClient() as client:
            for row in list_from_csv:
                dict_from_csv = dict(row)
                username = dict_from_csv['Assignee (doing the work)']
                projectPhase = dict_from_csv['Project Phase']
                ele = {
                    'username': username
                }
                user_id = None
                current_status = 1
                try:
                    connection = await connect_to_db()
                    query = f"select id from users where username = '{username}'"
                    user_id = await connection.fetch(query)
                    query = f"select id from lifecycle where phase = '{projectPhase}'"
                    current_status = (await connection.fetch(query))[0]['id']
                    await close_db_connection(connection)
                except Exception as e:
                    return JSONResponse(status_code=500, content={"message2": str(e)})

                assinged_to = None
                if len(user_id) == 0:
                    assinged_to = (await client.post(f'{baseURL}/api/users/', json=ele, headers=headers)).json()['response']['id']
                else:
                    assinged_to = user_id[0]['id']

                date_format = "%m/%d/%Y"
                ele = {
                    'type': dict_from_csv['Log Type'],
                    'name': 'Issue',
                    'iwantto': dict_from_csv['Description (needs to read: "I need this...so I can accomplish this...)'],
                    'assigned_to': assinged_to,
                    'current_status': current_status,
                    'velocityPoints': dict_from_csv['Velocity Points in Sprint (Story points Dynamic): 1 day effort = 1 point; a SPRINT = 10 days'],
                    'sprint': dict_from_csv['Sprint (usually 2 weeks): 1 FTE = 5 working days (1 day = 1 velocity point, e.g. 5 days = 5 v-points)'],
                    'taskDuration': dict_from_csv['Task Duration'],
                    'actualStartDate': str(datetime.strptime(dict_from_csv['Sprint Start date(2week sprint)'], date_format).date()),
                    'actualEndDate': str(datetime.strptime(dict_from_csv['End date'], date_format).date()),
                    'plannedStartDate': str(datetime.strptime(dict_from_csv['Scheduled Start Date(perfect senario)'], date_format).date()),
                    'plannedEndDate': str(datetime.strptime(dict_from_csv['Scheduled End Date'], date_format).date()),
                }

                # Post the story and then fetch the most recent story ID
                await client.post(f'{baseURL}/api/stories/', json=ele, headers=headers)
                recent_story_id = await get_recent_story_id()

                if recent_story_id:
                    story_ids.append(recent_story_id)
                else:
                    return JSONResponse(status_code=500, content={"message": "Failed to retrieve the story ID."})

    return JSONResponse(status_code=200, content={"message": "Successfully processed the Jira CSV file!", "story_ids": story_ids})


@chatbot_router.post("/api/uploadjira", summary="Upload Jira xls file")
async def create_upload_jirafile(file: UploadFile = File(...), db: Session = Depends(get_db)):
    try:
        # Save the uploaded file
        date_today = datetime.now().strftime('%Y-%m-%d')
        directory = f'./uploads/{date_today}'

        if not os.path.exists(directory):
            os.makedirs(directory)

        date_time_now = datetime.now().strftime('%H%M%S%f')
        filename = f"{date_time_now}_{file.filename}"
        file_location = f"{directory}/{filename}"

        # Save the file to the specified location
        with open(file_location, "wb+") as file_object:
            file_object.write(await file.read())

        # Call the get_xls_file_content function to process the file and get story IDs
        response = await get_xls_file_content(file_location)
        story_ids = json.loads(response.body)['story_ids']

        # Generate a single query string that includes all the story_ids
        story_ids_str = ','.join(map(str, story_ids))

        # Create queries that request analysis for all stories at once
        query_text_cost = f"Get me the cost analysis for the story ids {story_ids_str}"
        query_text_project = f"Get me the project analysis for the story ids {story_ids_str}"
        query_text_risk = f"Get me the risk analysis for the story ids {story_ids_str}"

        # Get the responses for all stories at once
        cost_response = await process_cost_query(query_text_cost, db)
        risk_response = await process_risk_query(query_text_risk, db)
        project_response = await process_project_query(query_text_project, db)

        # Return the final response, including all analyses for all stories
        return JSONResponse(status_code=200, content={
            "message": "Jira CSV file processed successfully!",
            "story_ids": story_ids,
            "project_analysis": project_response,
            "risk_analysis": risk_response,
            "cost_analysis": cost_response,
        })

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": f"An error occurred: {str(e)}"})
