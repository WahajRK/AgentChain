from typing import Optional
from pydantic import BaseModel, Field, ConfigDict

class RephrasedResponseBaseSchema(BaseModel):
    query_id: Optional[int] = None
    response_text: Optional[str] = None

class RephrasedResponseCreateSchema(RephrasedResponseBaseSchema):
    pass

class RephrasedResponseReadSchema(RephrasedResponseBaseSchema):
    model_config = ConfigDict(from_attributes=True)

    response_id: int

class RephrasedResponseUpdateSchema(RephrasedResponseBaseSchema):
    pass

class ResponseRephrasedResponseSchema(BaseModel):
    code: str
    status: int
    response: str | RephrasedResponseReadSchema = Field(...)

class ListResponseRephrasedResponseSchema(BaseModel):
    code: str
    status: int
    response: list[RephrasedResponseReadSchema] = Field(...)
