from sqlalchemy.orm import Session
from models.rephrasedresponses import RephrasedResponse
from schemas.rephrasedresponses import RephrasedResponseCreateSchema, RephrasedResponseUpdateSchema

def get_rephrasedresponses(db: Session, skip: int = 0, limit: int = 100):
    return db.query(RephrasedResponse).offset(skip).limit(limit).all()

def get_rephrasedresponse_by_id(db: Session, response_id: int):
    return db.query(RephrasedResponse).filter(RephrasedResponse.response_id == response_id).first()

def create_rephrasedresponse(db: Session, rephrasedresponse: RephrasedResponseCreateSchema):
    db_rephrasedresponse = RephrasedResponse(
        query_id=rephrasedresponse.query_id,
        response_text=rephrasedresponse.response_text
    )
    db.add(db_rephrasedresponse)
    db.commit()
    db.refresh(db_rephrasedresponse)
    return db_rephrasedresponse

def delete_rephrasedresponse(db: Session, response_id: int):
    db_rephrasedresponse = db.query(RephrasedResponse).filter(RephrasedResponse.response_id == response_id).first()
    db.delete(db_rephrasedresponse)
    db.commit()

def update_rephrasedresponse(db: Session, response_id: int, rephrasedresponse: RephrasedResponseUpdateSchema):
    db_rephrasedresponse = db.query(RephrasedResponse).filter(RephrasedResponse.response_id == response_id).first()
    db_rephrasedresponse.query_id = rephrasedresponse.query_id
    db_rephrasedresponse.response_text = rephrasedresponse.response_text
    db.commit()
    db.refresh(db_rephrasedresponse)
    return db_rephrasedresponse
