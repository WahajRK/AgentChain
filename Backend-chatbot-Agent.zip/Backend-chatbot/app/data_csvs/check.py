import pandas as pd
df_risk = pd.read_csv("risks.csv")
print(df_risk.dtypes)

# Convert 'name' and 'description' to string
df_risk['name'] = df_risk['name'].astype(str)
df_risk['description'] = df_risk['description'].astype(str)
df_risk['mitigation'] = df_risk['mitigation'].astype(str)

# Convert 'risk_probablitly' to integer
df_risk['risk_probablitly'] = pd.to_numeric(df_risk['risk_probablitly'], errors='coerce', downcast='integer')

# Convert 'DueDate' to datetime
df_risk['DueDate'] = pd.to_datetime(df_risk['DueDate'], errors='coerce', format='%Y%m%d')  # Adjust format if needed

# Convert float columns to integer (for nullable columns)
df_risk['risk_proj_id'] = df_risk['risk_proj_id'].fillna(0).astype('Int64')  # Use Int64 for nullable integers
df_risk['risk_prog_id'] = df_risk['risk_prog_id'].fillna(0).astype('Int64')
df_risk['risk_port_id'] = df_risk['risk_port_id'].fillna(0).astype('Int64')

# Print the corrected data types
print(df_risk.dtypes)

# Save the corrected DataFrame to a new CSV
df_risk.to_csv('risks_corrected.csv', index=False)